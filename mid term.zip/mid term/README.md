# <a href="https://github.com/AmanpreetKaurIshar/midterm" target="_blank">split-test</a>

An engine for splitting the traffic between sites.

